class HiveTabelConstant{
  HiveTabelConstant._();

  static const int userTableId = 0;
  static const String userBox = 'userBox';

  static const int batchTableId = 1;
  static const String batchBox = 'batchBox';
  
  static const int courseTableId = 2;
  static const String courseBox = 'courseBox';
}