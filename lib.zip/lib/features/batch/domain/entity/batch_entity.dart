class BatchEntity {
  final String? batchId;
  final String? batchName;

  BatchEntity({this.batchId, required this.batchName});
}
