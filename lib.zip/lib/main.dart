import 'package:flutter/material.dart';
import 'package:student_management/app.dart';
import 'package:student_management/login_view.dart';

void main() {
  runApp(const App());
}

